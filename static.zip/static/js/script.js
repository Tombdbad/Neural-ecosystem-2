
// Neural Ecosystem Dashboard JavaScript
// Real-time updates and interaction handling

const socket = io();
let currentTab = 'overview';
let charts = {}; // Store chart instances

// Tab Management
function openTab(event, tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(el => {
        el.classList.remove('active');
    });
    
    // Remove active class from all buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    if (event && event.target) {
        event.target.classList.add('active');
    }
    
    currentTab = tabName;
    updateTab(tabName);
}

// Socket Events
socket.on('connect', () => {
    console.log('🔗 Connected to Neural Ecosystem');
    if (document.getElementById('connectionStatus')) {
        document.getElementById('connectionStatus').textContent = '🔗 Connected';
    }
    updateTab(currentTab);
});

socket.on('disconnect', () => {
    console.log('❌ Disconnected from Neural Ecosystem');
    if (document.getElementById('connectionStatus')) {
        document.getElementById('connectionStatus').textContent = '❌ Disconnected';
    }
});

socket.on('update', data => {
    updateTab(currentTab);
});

// Update Functions
function updateTab(tab) {
    try {
        switch(tab) {
            case 'overview':
                updateOverview();
                break;
            case 'population':
                updatePopulation();
                break;
            case 'keepers':
                updateKnowledgeKeepers();
                break;
            case 'temporal':
                updateTemporal();
                break;
            case 'relationships':
                updateRelationships();
                break;
            case 'feed':
                updateFeed();
                break;
        }
    } catch (error) {
        console.error(`Error updating ${tab}:`, error);
    }
}

function updateOverview() {
    fetch('/api/ecosystem_state')
        .then(res => res.json())
        .then(data => {
            // Update status bar
            const stepEl = document.getElementById('stepCounter');
            const countEl = document.getElementById('beingCount');
            if (stepEl) stepEl.textContent = `Step: ${data.step_count}`;
            if (countEl) countEl.textContent = `Beings: ${data.being_count}`;
            
            // Update metrics
            const stageEl = document.getElementById('developmentStage');
            const energyEl = document.getElementById('avgEnergy');
            const wisdomEl = document.getElementById('totalWisdom');
            
            if (stageEl) stageEl.textContent = data.current_stage;
            if (energyEl) energyEl.textContent = data.average_energy.toFixed(1);
            if (wisdomEl) wisdomEl.textContent = data.community_wisdom.toFixed(1);
            
            // Draw grid
            drawEcosystemGrid(data.grid, data.beings);
            
            // Update gauges
            updateVitalityGauge(data.system_vitality);
            updateEmergenceMeter(data.emergence_score);
            updateWisdomMeter(data.community_wisdom);
        })
        .catch(err => {
            console.error('Overview update error:', err);
            // Show fallback data
            drawEcosystemGrid([], []);
        });
}

function drawEcosystemGrid(grid, beings) {
    const canvas = document.getElementById('gridCanvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, 700, 700);
    
    // Draw grid lines
    ctx.strokeStyle = '#0f0';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 7; i++) {
        // Vertical lines
        ctx.beginPath();
        ctx.moveTo(i * 100, 0);
        ctx.lineTo(i * 100, 700);
        ctx.stroke();
        
        // Horizontal lines
        ctx.beginPath();
        ctx.moveTo(0, i * 100);
        ctx.lineTo(700, i * 100);
        ctx.stroke();
    }
    
    // Draw beings
    if (beings && Array.isArray(beings)) {
        beings.forEach(being => {
            if (being.position && Array.isArray(being.position)) {
                const [x, y] = being.position;
                if (x >= 0 && x < 7 && y >= 0 && y < 7) {
                    const centerX = x * 100 + 50;
                    const centerY = y * 100 + 50;
                    
                    // Being circle
                    ctx.beginPath();
                    ctx.arc(centerX, centerY, 20, 0, 2 * Math.PI);
                    
                    // Color based on energy
                    if (being.energy > 80) {
                        ctx.fillStyle = '#00ff00';
                    } else if (being.energy > 50) {
                        ctx.fillStyle = '#ffff00';
                    } else {
                        ctx.fillStyle = '#ff4400';
                    }
                    
                    ctx.fill();
                    ctx.strokeStyle = '#0f0';
                    ctx.lineWidth = 2;
                    ctx.stroke();
                    
                    // Being ID
                    ctx.fillStyle = '#000';
                    ctx.font = '12px monospace';
                    ctx.textAlign = 'center';
                    ctx.fillText(being.unique_id, centerX, centerY + 4);
                    
                    // Wisdom indicator
                    if (being.accumulated_wisdom > 1) {
                        ctx.beginPath();
                        ctx.arc(centerX + 15, centerY - 15, 5, 0, 2 * Math.PI);
                        ctx.fillStyle = '#00ffff';
                        ctx.fill();
                    }
                }
            }
        });
    }
}

function updateVitalityGauge(vitality) {
    const arc = document.getElementById('vitalityArc');
    const needle = document.getElementById('vitalityNeedle');
    
    if (!arc || !needle) return;
    
    // Update arc
    const circumference = 251;
    const offset = circumference - (vitality / 100) * circumference;
    arc.setAttribute('stroke-dasharray', `${circumference - offset} ${circumference}`);
    
    // Update needle
    const angle = -90 + (vitality / 100) * 180;
    const radians = (angle * Math.PI) / 180;
    const length = 70;
    const x2 = 100 + length * Math.cos(radians);
    const y2 = 90 + length * Math.sin(radians);
    needle.setAttribute('x2', x2);
    needle.setAttribute('y2', y2);
}

function updateEmergenceMeter(emergenceScore) {
    const canvas = document.getElementById('emergenceMeter');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 200, 100);
    
    // Background arc
    ctx.beginPath();
    ctx.arc(100, 90, 70, Math.PI, 2 * Math.PI, false);
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 15;
    ctx.stroke();
    
    // Progress arc
    ctx.beginPath();
    ctx.arc(100, 90, 70, Math.PI, Math.PI + (emergenceScore / 100) * Math.PI, false);
    ctx.strokeStyle = '#0f0';
    ctx.lineWidth = 15;
    ctx.stroke();
    
    // Needle
    const needleAngle = Math.PI + (emergenceScore / 100) * Math.PI;
    ctx.beginPath();
    ctx.moveTo(100, 90);
    ctx.lineTo(100 + 60 * Math.cos(needleAngle), 90 + 60 * Math.sin(needleAngle));
    ctx.strokeStyle = '#ff0';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Value text
    ctx.fillStyle = '#0f0';
    ctx.font = '14px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`${emergenceScore.toFixed(1)}%`, 100, 105);
}

function updateWisdomMeter(wisdom) {
    const canvas = document.getElementById('wisdomMeter');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 200, 100);
    
    // Background
    ctx.fillStyle = '#111';
    ctx.fillRect(10, 70, 180, 20);
    
    // Progress bar
    const wisdomPercent = Math.min(100, (wisdom / 50) * 100);
    ctx.fillStyle = '#0f0';
    ctx.fillRect(10, 70, (wisdomPercent / 100) * 180, 20);
    
    // Border
    ctx.strokeStyle = '#0f0';
    ctx.lineWidth = 2;
    ctx.strokeRect(10, 70, 180, 20);
    
    // Value text
    ctx.fillStyle = '#0f0';
    ctx.font = '14px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`${wisdom.toFixed(1)}`, 100, 85);
}

function updatePopulation() {
    Promise.all([
        fetch('/api/ecosystem_state').then(res => res.json()),
        fetch('/api/population_analysis').then(res => res.json())
    ]).then(([ecoData, popData]) => {
        updateBeingTable(ecoData.beings || []);
        updatePopulationCharts(popData);
    }).catch(err => console.error('Population update error:', err));
}

function updateBeingTable(beings) {
    const tbody = document.querySelector('#beingTable tbody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    const filter = document.getElementById('beingFilter')?.value || 'all';
    
    beings.forEach(being => {
        if (filter !== 'all' && being.current_growth_stage !== filter) {
            return;
        }
        
        const row = document.createElement('tr');
        
        // Energy cell with color coding
        const energyClass = being.energy > 80 ? 'green' : being.energy > 50 ? 'yellow' : 'red';
        
        row.innerHTML = `
            <td>${being.unique_id}</td>
            <td class="${energyClass}">${being.energy.toFixed(1)}</td>
            <td>${being.accumulated_wisdom.toFixed(2)}</td>
            <td>${being.current_growth_stage}</td>
            <td>${being.social_connections}</td>
            <td>[${being.position[0]}, ${being.position[1]}]</td>
            <td>${being.neurochemical_state.empathy.toFixed(2)}</td>
            <td>${being.neurochemical_state.curiosity.toFixed(2)}</td>
        `;
        
        row.onclick = () => showBeingDetail(being.unique_id);
        tbody.appendChild(row);
    });
}

function updatePopulationCharts(popData) {
    const energyCtx = document.getElementById('energyDistChart');
    if (!energyCtx) return;
    
    // Destroy existing chart
    if (charts.energyChart) {
        charts.energyChart.destroy();
    }
    
    const energyDist = popData.energy_distribution || {};
    
    charts.energyChart = new Chart(energyCtx, {
        type: 'bar',
        data: {
            labels: Object.keys(energyDist),
            datasets: [{
                label: 'Energy Distribution',
                data: Object.values(energyDist),
                backgroundColor: ['#ff0000', '#ff4400', '#ffff00', '#88ff00', '#00ff00']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { labels: { color: '#0f0' } }
            },
            scales: {
                y: { 
                    beginAtZero: true,
                    ticks: { color: '#0f0' },
                    grid: { color: '#333' }
                },
                x: {
                    ticks: { color: '#0f0' },
                    grid: { color: '#333' }
                }
            }
        }
    });
}

function updateKnowledgeKeepers() {
    fetch('/api/knowledge_keeper_status')
        .then(res => res.json())
        .then(data => {
            // Social Knowledge Keeper
            const socialRel = document.getElementById('socialRelationships');
            const socialTrust = document.getElementById('socialTrust');
            const socialEmpathy = document.getElementById('socialEmpathy');
            
            if (socialRel) socialRel.textContent = data.social_keeper.relationship_discoveries;
            if (socialTrust) socialTrust.textContent = data.social_keeper.trust_observations;
            if (socialEmpathy) socialEmpathy.textContent = data.social_keeper.empathy_emergences;
            
            // Individual Knowledge Keeper
            const indGrowth = document.getElementById('individualGrowth');
            const indInsights = document.getElementById('individualInsights');
            const indCompassion = document.getElementById('individualCompassion');
            const indCuriosity = document.getElementById('individualCuriosity');
            
            if (indGrowth) indGrowth.textContent = data.individual_keeper.growth_patterns_learned;
            if (indInsights) indInsights.textContent = data.individual_keeper.development_insights;
            if (indCompassion) indCompassion.textContent = data.individual_keeper.compassion_level.toFixed(2);
            if (indCuriosity) indCuriosity.textContent = data.individual_keeper.curiosity_level.toFixed(2);
            
            // Collaboration metrics
            const collabMetrics = document.getElementById('collaborationMetrics');
            if (collabMetrics && data.collaboration) {
                collabMetrics.innerHTML = `
                    <div class="metric">
                        <label>Total Collaborations:</label>
                        <span>${data.collaboration.total_collaborations}</span>
                    </div>
                    <div class="metric">
                        <label>Development Phase:</label>
                        <span>${data.collaboration.development_phase}</span>
                    </div>
                    <div class="metric">
                        <label>Effectiveness:</label>
                        <span>${(data.collaboration.collaboration_effectiveness * 100).toFixed(1)}%</span>
                    </div>
                `;
            }
        })
        .catch(err => console.error('Knowledge Keepers update error:', err));
}

function updateTemporal() {
    fetch('/api/temporal_development')
        .then(res => res.json())
        .then(data => {
            updateStageProgression(data.current_stage);
            updateMilestones(data.milestones || []);
            updateTemporalChart(data);
        })
        .catch(err => console.error('Temporal update error:', err));
}

function updateStageProgression(currentStage) {
    const progression = document.getElementById('stageProgression');
    if (!progression) return;
    
    const stages = [
        'forming_community',
        'early_exploration', 
        'active_development',
        'wisdom_integration',
        'mature_community'
    ];
    
    progression.innerHTML = stages.map(stage => 
        `<div class="stage-indicator ${stage === currentStage ? 'active' : ''}">${stage.replace('_', ' ')}</div>`
    ).join('');
}

function updateMilestones(milestones) {
    const milestonesList = document.getElementById('milestonesList');
    if (!milestonesList) return;
    
    milestonesList.innerHTML = '';
    
    milestones.slice(-10).forEach(milestone => {
        const item = document.createElement('div');
        item.className = 'milestone-item';
        item.innerHTML = `
            <div class="milestone-type">${milestone.type}</div>
            <div class="milestone-desc">${milestone.description}</div>
            <div class="milestone-step">Step: ${milestone.step}</div>
        `;
        milestonesList.appendChild(item);
    });
}

function updateTemporalChart(data) {
    const ctx = document.getElementById('temporalChart');
    if (!ctx) return;
    
    const timeScale = document.getElementById('timeScale')?.value || 'daily';
    
    // Destroy existing chart
    if (charts.temporalChart) {
        charts.temporalChart.destroy();
    }
    
    let chartData = [];
    let labels = [];
    
    if (data[timeScale + '_patterns']) {
        const patterns = data[timeScale + '_patterns'];
        chartData = patterns.map(p => p.metrics?.average_energy || 75);
        labels = patterns.map((p, i) => `${timeScale.charAt(0).toUpperCase()}${i + 1}`);
    } else {
        // Fallback data
        chartData = [75, 78, 82, 79, 85, 88, 84];
        labels = ['Day1', 'Day2', 'Day3', 'Day4', 'Day5', 'Day6', 'Day7'];
    }
    
    charts.temporalChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Average Energy',
                data: chartData,
                borderColor: '#0f0',
                backgroundColor: 'rgba(0, 255, 0, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { labels: { color: '#0f0' } }
            },
            scales: {
                y: { 
                    beginAtZero: true,
                    ticks: { color: '#0f0' },
                    grid: { color: '#333' }
                },
                x: {
                    ticks: { color: '#0f0' },
                    grid: { color: '#333' }
                }
            }
        }
    });
}

function updateRelationships() {
    fetch('/api/relationships')
        .then(res => res.json())
        .then(relationships => {
            drawNetworkGraph(relationships);
            updateRelationshipMetrics(relationships);
        })
        .catch(err => console.error('Relationships update error:', err));
}

function drawNetworkGraph(relationships) {
    const canvas = document.getElementById('networkGraph');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 800, 600);
    
    // Get unique being IDs
    const beingIds = [...new Set([
        ...relationships.map(r => r.from),
        ...relationships.map(r => r.to)
    ])];
    
    if (beingIds.length === 0) {
        // Draw default nodes for beings 1, 2, 3
        beingIds.push(1, 2, 3);
    }
    
    // Position beings in a circle
    const positions = {};
    const centerX = 400;
    const centerY = 300;
    const radius = 200;
    
    beingIds.forEach((id, i) => {
        const angle = (i / beingIds.length) * 2 * Math.PI;
        positions[id] = {
            x: centerX + radius * Math.cos(angle),
            y: centerY + radius * Math.sin(angle)
        };
    });
    
    // Draw relationships
    relationships.forEach(rel => {
        const fromPos = positions[rel.from];
        const toPos = positions[rel.to];
        
        if (fromPos && toPos) {
            ctx.beginPath();
            ctx.moveTo(fromPos.x, fromPos.y);
            ctx.lineTo(toPos.x, toPos.y);
            
            ctx.lineWidth = Math.max(1, (rel.strength || 0.5) * 5);
            
            switch(rel.type) {
                case 'supportive_care':
                    ctx.strokeStyle = '#00ff00';
                    break;
                case 'mutual_exploration':
                    ctx.strokeStyle = '#00ffff';
                    break;
                case 'wisdom_sharing':
                    ctx.strokeStyle = '#ffff00';
                    break;
                default:
                    ctx.strokeStyle = '#0f0';
            }
            
            ctx.stroke();
        }
    });
    
    // Draw beings as nodes
    Object.entries(positions).forEach(([id, pos]) => {
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 15, 0, 2 * Math.PI);
        ctx.fillStyle = '#0f0';
        ctx.fill();
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Being ID
        ctx.fillStyle = '#000';
        ctx.font = '12px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(id, pos.x, pos.y + 4);
    });
}

function updateRelationshipMetrics(relationships) {
    const metricsPanel = document.getElementById('relationshipMetrics');
    if (!metricsPanel) return;
    
    const typeCount = {};
    relationships.forEach(rel => {
        typeCount[rel.type] = (typeCount[rel.type] || 0) + 1;
    });
    
    metricsPanel.innerHTML = Object.entries(typeCount).map(([type, count]) => 
        `<div class="metric">
            <label>${type}:</label>
            <span>${count}</span>
        </div>`
    ).join('');
}

function updateFeed() {
    fetch('/api/live_events')
        .then(res => res.json())
        .then(events => {
            const stream = document.getElementById('eventStream');
            if (!stream) return;
            
            stream.innerHTML = events.map(event => 
                `<div class="event-line green">${event}</div>`
            ).join('');
            stream.scrollTop = stream.scrollHeight;
        })
        .catch(err => console.error('Feed update error:', err));
}

function showBeingDetail(beingId) {
    fetch(`/api/being/${beingId}`)
        .then(res => res.json())
        .then(being => {
            const detailPanel = document.getElementById('beingDetail');
            if (!detailPanel) return;
            
            detailPanel.innerHTML = `
                <h3>Being ${beingId} - Detailed View</h3>
                <div class="being-detail-grid">
                    <div class="detail-section">
                        <h4>Core Metrics</h4>
                        <div class="metric">Energy: ${being.energy.toFixed(1)}</div>
                        <div class="metric">Wisdom: ${being.accumulated_wisdom.toFixed(2)}</div>
                        <div class="metric">Experience: ${being.total_experience.toFixed(0)}</div>
                        <div class="metric">Stage: ${being.current_growth_stage}</div>
                    </div>
                    <div class="detail-section">
                        <h4>Neurochemical State</h4>
                        ${Object.entries(being.neurochemical_state).map(([key, value]) => 
                            `<div class="metric">${key}: ${value.toFixed(2)}</div>`
                        ).join('')}
                    </div>
                    <div class="detail-section">
                        <h4>Recent Activities</h4>
                        ${being.recent_activities.map(activity => 
                            `<div class="activity">${activity.type || activity}</div>`
                        ).join('')}
                    </div>
                </div>
            `;
            
            detailPanel.style.display = 'block';
        })
        .catch(err => console.error('Being detail error:', err));
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    console.log('🌟 Neural Ecosystem Dashboard initialized');
    
    // Initialize first tab
    openTab(null, 'overview');
    
    // Chat form
    const chatForm = document.getElementById('chatForm');
    if (chatForm) {
        chatForm.addEventListener('submit', e => {
            e.preventDefault();
            const queryInput = document.getElementById('queryInput');
            const query = queryInput.value.trim();
            
            if (!query) return;
            
            // Show user query
            const responseArea = document.getElementById('responseArea');
            if (responseArea) {
                responseArea.innerHTML += `<div class="chat-query">🧑 ${query}</div>`;
                
                fetch('/api/query', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({query})
                })
                .then(res => res.json())
                .then(data => {
                    responseArea.innerHTML += `<div class="chat-response green">🧠 ${data.response}</div>`;
                    responseArea.scrollTop = responseArea.scrollHeight;
                })
                .catch(err => {
                    responseArea.innerHTML += `<div class="chat-error red">Error: ${err.message}</div>`;
                });
                
                queryInput.value = '';
            }
        });
    }
    
    // Filter change handlers
    const beingFilter = document.getElementById('beingFilter');
    if (beingFilter) {
        beingFilter.addEventListener('change', () => updatePopulation());
    }
    
    const timeScale = document.getElementById('timeScale');
    if (timeScale) {
        timeScale.addEventListener('change', () => updateTemporal());
    }
    
    const relationshipFilter = document.getElementById('relationshipFilter');
    if (relationshipFilter) {
        relationshipFilter.addEventListener('change', () => updateRelationships());
    }
    
    // Set up auto-refresh
    setInterval(() => {
        updateTab(currentTab);
    }, 5000);
});
