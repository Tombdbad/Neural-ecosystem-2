// static/js/script.js
const socket = io();

function openTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
    document.getElementById(tabName).style.display = 'block';
    updateTab(tabName);
}

socket.on('update', data => {
    // Trigger updates for visible tabs
    const visibleTab = document.querySelector('.tab-content:not([style*="display: none"])');
    if (visibleTab) updateTab(visibleTab.id);
});

function updateTab(tab) {
    if (tab === 'overview') updateOverview();
    if (tab === 'population') updatePopulation();
    // Add for other tabs...
}

function updateOverview() {
    fetch('/api/ecosystem_state').then(res => res.json()).then(data => {
        // Draw grid
        const ctx = document.getElementById('gridCanvas').getContext('2d');
        ctx.clearRect(0,0,700,700);
        // Draw grid lines, beings as dots, etc.
        ctx.strokeStyle = '#0f0';
        for (let i = 0; i <= 7; i++) {
            ctx.beginPath(); ctx.moveTo(i*100,0); ctx.lineTo(i*100,700); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0,i*100); ctx.lineTo(700,i*100); ctx.stroke();
        }
        // Mock beings positions
        // For real, loop through data.grid or beings

        // Update gauge
        const vitality = data.system_vitality;
        const arc = document.getElementById('vitalityArc');
        const circumference = 251; // Approx 2 * PI * 80 / 2 for semi-circle
        arc.setAttribute('stroke-dasharray', `${(vitality / 100) * circumference} ${circumference}`);

        // Needle rotation
        const needle = document.getElementById('vitalityNeedle');
        const angle = -90 + (vitality / 100) * 180; // From left to right
        const length = 80;
        const x2 = 100 + length * Math.cos(angle * Math.PI / 180);
        const y2 = 90 + length * Math.sin(angle * Math.PI / 180);
        needle.setAttribute('x2', x2);
        needle.setAttribute('y2', y2);

        // Add animations with requestAnimationFrame if needed
        // Similar for other gauges using canvas
        const emergenceCtx = document.getElementById('emergenceMeter').getContext('2d');
        // Draw vintage meter with needle
        emergenceCtx.clearRect(0,0,200,100);
        // Draw arc
        emergenceCtx.beginPath();
        emergenceCtx.arc(100,90,80, Math.PI, 2*Math.PI, false);
        emergenceCtx.strokeStyle = '#ddd';
        emergenceCtx.lineWidth = 20;
        emergenceCtx.stroke();
        // Progress arc
        emergenceCtx.beginPath();
        emergenceCtx.arc(100,90,80, Math.PI, Math.PI + (data.emergence_score / 100) * Math.PI, false);
        emergenceCtx.strokeStyle = '#00ff00';
        emergenceCtx.stroke();
        // Needle
        const needleAngle = Math.PI + (data.emergence_score / 100) * Math.PI;
        emergenceCtx.beginPath();
        emergenceCtx.moveTo(100,90);
        emergenceCtx.lineTo(100 + 70 * Math.cos(needleAngle), 90 + 70 * Math.sin(needleAngle));
        emergenceCtx.strokeStyle = 'red';
        emergenceCtx.lineWidth = 2;
        emergenceCtx.stroke();
    });
}

function updatePopulation() {
    fetch('/api/population_analysis').then(res => res.json()).then(data => {
        // Update table
        const tbody = document.querySelector('#beingTable tbody');
        tbody.innerHTML = '';
        // Actually fetch beings from /api/ecosystem_state or separate
        fetch('/api/ecosystem_state').then(res => res.json()).then(sys => {
            sys.beings.forEach(b => {  // Assume beings in sys
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${b.unique_id}</td>
                    <td>${b.energy.toFixed(2)}</td>
                    <td>${b.accumulated_wisdom.toFixed(2)}</td>
                    <td>${b.current_growth_stage}</td>
                    <td>${b.social_connections}</td>
                    <td>${JSON.stringify(b.neurochemical_state)}</td>
                `;
                row.style.color = b.energy > 70 ? '.green' : b.energy > 30 ? '.yellow' : '.red';
                row.onclick = () => showBeingDetail(b.unique_id);
                tbody.appendChild(row);
            });
        });

        // Charts with Chart.js
        const energyCtx = document.getElementById('energyDist').getContext('2d');
        new Chart(energyCtx, {
            type: 'bar',
            data: {
                labels: ['Low', 'Med', 'High'],
                datasets: [{data: [1,2,3], backgroundColor: ['#f00', '#ff0', '#0f0']}]  // Mock
            },
            options: {scales: {y: {beginAtZero: true}}}
        });
    });
}

function showBeingDetail(id) {
    fetch(`/api/being/${id}`).then(res => res.json()).then(b => {
        const detail = document.getElementById('beingDetail');
        detail.innerHTML = `
            <h3>Being ${id}</h3>
            <div>Neurochemicals:</div>
            <!-- Add analog meters -->
            <svg class="meter" viewBox="0 0 100 50"> <!-- Example for empathy -->
                <path d="M5 45 A40 40 0 0 1 95 45" stroke="#ddd" stroke-width="10" fill="none"/>
                <path d="M5 45 A40 40 0 0 1 95 45" stroke="#0f0" stroke-width="10" fill="none" stroke-dasharray="${(b.neurochemical_state.empathy * 125.6)} 125.6"/>
            </svg>
            <!-- More for others -->
            <div>Recent Activities: ${b.recent_activities.join(', ')}</div>
            <!-- Network graph with Chart.js or canvas -->
        `;
    });
}

// Add functions for other tabs similarly...

// Chat form
document.getElementById('chatForm').addEventListener('submit', e => {
    e.preventDefault();
    const query = document.getElementById('queryInput').value;
    fetch('/api/query', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({query})})
        .then(res => res.json()).then(data => {
            document.getElementById('responseArea').innerHTML += `<p>${data.response}</p>`;
        });
});

// Update feed
function updateFeed() {
    fetch('/api/live_events').then(res => res.json()).then(events => {
        const stream = document.getElementById('eventStream');
        stream.innerHTML = events.map(e => `<p class="green">${e}</p>`).join('');
        stream.scrollTop = stream.scrollHeight;
    });
}

// For relationships, use canvas to draw network
function updateRelationships() {
    fetch('/api/relationships').then(res => res.json()).then(rels => {
        const ctx = document.getElementById('networkGraph').getContext('2d');
        ctx.clearRect(0,0,800,600);
        // Draw nodes and edges
        // Use simple positions, lines with thickness
    });
}

// Call initial
openTab('overview');
setInterval(() => {
    const visible = document.querySelector('.tab-content:not([style*="display: none"])');
    if (visible.id === 'feed') updateFeed();
}, 2000);